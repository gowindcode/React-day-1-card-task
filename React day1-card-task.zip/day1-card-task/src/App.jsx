// import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
import './App.css'


function App() {
  // const [count, setCount] = useState(0)

  return (
    <div>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
        <h1>React Price Card Task</h1>
          <div className="main-card"> 
             <div className="sub-card">
                <div className="box"><p>FREE <br/> <p className="price">$ 0/month <p className="line">_________________________ 
                   <div><p className="line-text"><span className="material-symbols-outlined">
                      check </span> 
                        Single user</p></div>
                          <div><p className="line-text"><span className="material-symbols-outlined">
                            check </span> 
                               50GB Storage</p></div>
                                <div><p className="line-text"><span className="material-symbols-outlined">
                                  check </span> 
                                    Unlimited Public Projects</p></div>  
                                  <div><p className="line-text"><span className="material-symbols-outlined">
                                check </span> 
                              Community Access</p></div>
                           <div><p className="line-text-close"><span className="material-symbols-outlined">
                        close</span> 
                      Unlimited Private Projects</p></div>
                    <div><p className="line-text-close"><span className="material-symbols-outlined">
                  close</span> 
              Dedicated Phone Support</p></div>
           <div><p className="line-text-close"><span className="material-symbols-outlined">
         close</span> 
       Free Subdomain</p></div>
     <div><p className="line-text-close"><span className="material-symbols-outlined">
    close</span> 
   Monthly Status Reports</p></div>
 <button className="button">BUTTON</button>
</p>
   </p>
      </p> 
         </div>
            <div className="box"><p>PLUS <br/> <p className="price">$ 9/month <p className="line">_________________________ 
               <div><p className="line-text"><span className="material-symbols-outlined">
                  check </span> 
                    Single user</p></div>
                       <div><p className="line-text"><span className="material-symbols-outlined">
                         check </span> 
                           50GB Storage</p></div>
                            <div><p className="line-text"><span className="material-symbols-outlined">
                               check </span> 
                                  Unlimited Public Projects</p></div>  
                                <div><p className="line-text"><span className="material-symbols-outlined">
                              check </span> 
                            Community Access</p></div>
                          <div><p className="line-text"><span className="material-symbols-outlined">
                        check</span> 
                      Unlimited Private Projects</p></div>
                    <div><p className="line-text"><span className="material-symbols-outlined">
                  check</span> 
                Dedicated Phone Support</p></div>
              <div><p className="line-text"><span className="material-symbols-outlined">
             check</span> 
            Free Subdomain</p></div>
          <div><p className="line-text-close"><span className="material-symbols-outlined">
         close</span> 
        Monthly Status Reports</p></div>
      <button className="button">BUTTON</button>
    </p></p></p></div>
  <div className="box"><p>PRO <br/> <p className="price">$ 49/month <p className="line">_________________________ 
 <div><p className="line-text"><span className="material-symbols-outlined">
   check </span> 
      Single user</p></div>
        <div><p className="line-text"><span className="material-symbols-outlined">
             check </span> 
                50GB Storage</p></div>
                  <div><p className="line-text"><span className="material-symbols-outlined">
                     check </span> 
                        Unlimited Public Projects</p></div>  
                          <div><p className="line-text"><span className="material-symbols-outlined">
                            check </span> 
                              Community Access</p></div>
                                <div><p className="line-text"><span className="material-symbols-outlined">
                                  check</span> 
                                   Unlimited Private Projects</p></div>
                                <div><p className="line-text"><span className="material-symbols-outlined">
                              check</span> 
                            Dedicated Phone Support</p></div>
                          <div><p className="line-text"><span className="material-symbols-outlined">
                        check</span> 
                      Free Subdomain</p></div>
                    <div><p className="line-text"><span className="material-symbols-outlined">
                  check</span> 
                Monthly Status Reports</p></div>
              <button className="button3">BUTTON</button>
            </p>
          </p>
        </p>
      </div>
    </div>
  </div>
</div>
      
    // <>
    //   <div>
    //     <a href="https://vitejs.dev" target="_blank">
    //       <img src={viteLogo} className="logo" alt="Vite logo" />
    //     </a>
    //     <a href="https://react.dev" target="_blank">
    //       <img src={reactLogo} className="logo react" alt="React logo" />
    //     </a>
    //   </div>
    //   <h1>Vite + React</h1>
    //   <div className="card">
    //     <button onClick={() => setCount((count) => count + 1)}>
    //       count is {count}
    //     </button>
    //     <p>
    //       Edit <code>src/App.jsx</code> and save to test HMR
    //     </p>
    //   </div>
    //   <p className="read-the-docs">
    //     Click on the Vite and React logos to learn more
    //   </p>
    // </>
  )
}

export default App
